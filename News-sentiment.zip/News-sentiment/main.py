from urllib.request import Request, urlopen
from bs4 import BeautifulSoup
import feedparser
from transformers import pipeline
import json
import time
import random

pipe = pipeline(
    "text-classification",
    model="mrm8488/distilroBERTa-finetuned-financial-news-sentiment-analysis")

#selecting stocks from respository
finviz_url = 'https://finviz.com/quote.ashx?t='
tickers = ['TSLA', 'FSLR', 'TAN', 'PLUG']

#gathering html data from each stock and sorting
parsed_tables = {}

time.sleep(random.uniform(1, 3))

#fetch and parse data for each ticker
for ticker in tickers:
    url = finviz_url + ticker
    try:
        req = Request(url=url, headers={'user-agent': 'my-app'})
        response = urlopen(req)
    
        parsed_ticker_table = []
    
        html = BeautifulSoup(response, 'html.parser')
        news_table = html.find(id='news-table')
    
        if news_table:
            rows = news_table.find_all('tr')
            for row in rows:
                link_tag = row.find("a")
                if link_tag:
                    title = link_tag.get_text()
                    td_tag = row.find('td')
                    timestamp = td_tag.get_text().strip() if td_tag else "N/A"
                    
                    parsed_ticker_table.append({
                        "timestamp": timestamp,
                        "title": title
                    })
    except Exception as e:
        print(f"Error fetching data for {ticker}: {e}")
    parsed_tables[ticker] = parsed_ticker_table

#final structured data storage
sentiment_data = []

for ticker, news_list in parsed_tables.items():
    print(f"\n--- Analyzing {ticker} ---")

    for item in news_list:
        headline = item['title']
        timestamp = item['timestamp']

        #run sentiment
        prediction = pipe(headline)
        label = prediction[0]['label']
        score = round(prediction[0]['score'], 4)

        #store combined data for cross referencing
        sentiment_data.append({
            "ticker": ticker,
            "timestamp": timestamp,
            "headline": headline,
            "sentiment": label,
            "confidence": score
        })

        print(f"[{label}] {headline} (Conf: {score})")

#save to a json file for future cross referencing
with open('sentiment_results.json', 'w') as f:
    json.dump(sentiment_data, f, indent=4)

print(f"\nStored {len(sentiment_data)} sentiment results to 'sentiment_results.json'")
